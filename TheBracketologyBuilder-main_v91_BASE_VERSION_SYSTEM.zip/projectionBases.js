
// Projection base version system
// Base datasets are immutable snapshots of the Round of 64.
// Do NOT modify old bases. Add new ones when projections update.

export const CURRENT_BASE_VERSION = 1;

export const PROJECTION_BASES = {
  1: {
    version: 1,
    created: "base_1_initial_projection"
  }
};
